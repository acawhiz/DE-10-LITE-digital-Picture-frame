﻿// Author: Leonardo Tazzini
// Blog: http://electro-logic.blogspot.it/
//http://electro-logic.blogspot.com/2016/08/fpga-comunicazione-tramite-jtag-uart.html?m=1
//https://github.com/twinearthsoftware/IntelHexFormatReader

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace JtagAtlanticDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                JTAG_TRANSFER();
                //upload_data();
                // EchoSample();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void JTAG_TRANSFER()
        {
            string path = @"C:\NotBackedUp\intelFPGA_lite\DE10-Lite Board\vga_pics\secuence.hex";
            System.IO.StreamReader sr = new System.IO.StreamReader(path);
            int lines = 0; byte lsb, msb;
            while (!sr.EndOfStream)
            {
                String strText = sr.ReadLine();
                if (strText.Equals(":00000001FF") | strText.Equals(":020000040001F9") | strText.Equals(":020000040002F8") | strText.Equals(":020000040003F7") | strText.Equals(":020000040004F6"))
                {
                    Console.WriteLine(strText);
                }
                else
                {
                    //Console.WriteLine(strText.Substring(9, 4));
                    lsb = Convert.ToByte(strText.Substring(11, 2), 16);
                    msb = Convert.ToByte(strText.Substring(9, 2), 16);

                    lines++;
                }
            }
            sr.Close();


        }
















        static void filereadtest()
        {
            string path = @"C:\NotBackedUp\intelFPGA_lite\DE10-Lite Board\vga_pics\secuence.hex";
            System.IO.StreamReader sr = new  System.IO.StreamReader(path);
            int lines=0;byte lsb,msb;
            while (!sr.EndOfStream)
            {
                String strText = sr.ReadLine();
                if (strText.Equals(":00000001FF")| strText.Equals(":020000040001F9") | strText.Equals(":020000040002F8") | strText.Equals(":020000040003F7") | strText.Equals(":020000040004F6"))
                {
                    Console.WriteLine(strText);
                }
                else
                {
                    //Console.WriteLine(strText.Substring(9, 4));
                    lsb = Convert.ToByte(strText.Substring(11, 2), 16);
                    msb = Convert.ToByte(strText.Substring(9, 2), 16);
                    
                    lines++;
                }
            }
            sr.Close();

            
        }




        static void upload_data()
        {
            using (JtagUart jtag = new JtagUart())
            {
                var info = jtag.GetConnectionInfo();
                Console.WriteLine("Connected to [Cable: {0} Device: {1} Instance: {2}]", info.Cable, info.Device, info.Instance);

                jtag.WriteByte(0x01);//SOH
                Console.WriteLine("Tx:0x01");

                
                byte data_from_board = jtag.ReadByte();
                Console.WriteLine("Rx:"+ Convert.ToString(data_from_board, 16));

                if (data_from_board==0x02)
                {
                    int page_data_counter = 0;

                    for (uint i = 0; i < 640*480*2; i+=2)
                    {
                        byte lsb = (byte)i;
                        byte msb = (byte)(i+1);
                        jtag.WriteByte(lsb);
                        jtag.WriteByte(msb);
                        page_data_counter++;
                        // System.Threading.Thread.Sleep(5);
                        //Debug.WriteLine(Convert.ToString(data, 2).PadLeft(8, '0'));
                        //Console.WriteLine(Convert.ToString(i, 10).PadLeft(4, ' ')+":"+ Convert.ToString(data, 10).PadLeft(4, ' '));
                    }

                    data_from_board = jtag.ReadByte();
                    Console.WriteLine("Rx:" + Convert.ToString(data_from_board, 16));
                }
                // Console.Write(Encoding.ASCII.GetString(new byte[] { data_from_board }));
                Debug.WriteLine(Convert.ToString(data_from_board));

                Console.WriteLine("Program terminated. Press a key to exit.");
                Console.ReadKey();
            }

        }

        static void EchoSample()
        {
            // using keyword allow closing connection also if an error happen
            using (JtagUart jtag = new JtagUart())
            {
                // Display connection info
                var info = jtag.GetConnectionInfo();
                Console.WriteLine("Connected to [Cable: {0} Device: {1} Instance: {2}]", info.Cable, info.Device, info.Instance);

                // We create two thread, one for reading and one for writing console
                // Reading thread terminate when CTRL+Z, F6 or end-of-stream occuor into stdin        
                // When Reading thread terminate we set a flag to terminate also Write thread
                // when another character occuor (or when program terminate) and then we terminate program        

                // Read thread. Send data to board

                var readThread = Task.Factory.StartNew(() =>
                { 
                    while (true)
                    {

                        


                        //int character = Console.Read();//read input from keyboard
                        string s = Console.ReadLine();//read input from keyboard
                        //byte[] charByte = Encoding.ASCII.GetBytes(s);
                        byte[] charByte = new byte[1024];

                        for (UInt16 i = 0; i < 1024; i++)
                        {

                            charByte[i] = (byte)i;
                            
                        }
                        //Debug.WriteLine(BitConverter.ToString(charByte));
                        //if (character == -1)
                        if (s.Length== 0)
                        break;
                        else
                        {

                            //jtag.Write(charByte);
                            //jtag.WriteByte((byte)character);
                            //byte[] data = { 0xff, 0x33, 0x55 };
                            jtag.Write(charByte);
                        }


                    }
                });

                // flag to quit Write thread
                bool writeThreadAbort = false;

                // Write thread. Receive from Board
                var writeThread = Task.Factory.StartNew(() =>
                {
                    try
                    {
                        while (true)
                        {
                            if (writeThreadAbort == true)
                                break;

                            Console.Write(Encoding.ASCII.GetString(new byte[] { jtag.ReadByte() }));
                        }
                    }
                    catch (AccessViolationException)
                    {
                        // thrown when Write thread is in jtag.ReadByte(), Read thread terminate, and there is nothing to read                        
                    }
                });

                readThread.Wait();
                writeThreadAbort = true;                

                Console.WriteLine("Program terminated. Press a key to exit.");
                Console.ReadKey();
            }
        }


        ////
        ///

        ////
    }
}
