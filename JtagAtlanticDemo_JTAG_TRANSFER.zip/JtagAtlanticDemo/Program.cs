﻿// Blog: http://electro-logic.blogspot.it/
//http://electro-logic.blogspot.com/2016/08/fpga-comunicazione-tramite-jtag-uart.html?m=1
//https://github.com/twinearthsoftware/IntelHexFormatReader

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



namespace JtagAtlanticDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                JTAG_TRANSFER();
                //upload_data();
                // EchoSample();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void JTAG_TRANSFER()
        {
            //  string path = @"C:\intelFPGA_lite\DE10-Lite Board\vga_pics\secuence.hex";
            //string path = @"C:\intelFPGA_lite\DE10-LiteBoard\vga_pics\vga1.hex";
            // string path = @"C:\intelFPGA_lite\DE10-LiteBoard\vga_pics\vga2.hex";
           //   string path = @"C:\intelFPGA_lite\DE10-LiteBoard\Projects\UDEMY\vga1.hex";
            System.IO.StreamReader sr = new System.IO.StreamReader(path);
            int data_count = 0; byte lsb, msb;
            int page_data_counter = 0;
            int page_counter = 0;
            ////////////////////////////JTAG SETUP///////////////////////
            ///
            using (JtagUart jtag = new JtagUart())
            {
                var info = jtag.GetConnectionInfo();
                Console.WriteLine("Connected to [Cable: {0} Device: {1} Instance: {2}]", info.Cable, info.Device, info.Instance);
                jtag.WriteByte(0x01);//SOH
                Console.WriteLine("Tx:0x01");
                byte data_from_board = jtag.ReadByte();
                Console.WriteLine("Rx:" + Convert.ToString(data_from_board, 16));

                if (data_from_board == 0x02)
                {

                    ///////////////////////////END JTAG SETUP////////////////////

                    while (!sr.EndOfStream)
                    {
                        String strText = sr.ReadLine();
                        if (strText.Equals(":00000001FF") | strText.Equals(":020000040001F9") | strText.Equals(":020000040002F8") | strText.Equals(":020000040003F7") | strText.Equals(":020000040004F6"))
                        {
                            Console.WriteLine(strText);
                        }
                        
                        else/* if(data_count<=0x4afff)*/
                        {
                            //Console.WriteLine(strText.Substring(9, 4));
                            lsb = Convert.ToByte(strText.Substring(11, 2), 16);
                            msb = Convert.ToByte(strText.Substring(9, 2), 16);
                            page_data_counter++;
                            jtag.WriteByte(lsb);
                            jtag.WriteByte(msb);
                            data_count++;
                            //Thread.Sleep(1);
                            
                            if ((page_data_counter == 1024)/* & (data_count!=0x4afff)*/)
                            {
                                page_counter++;
                                //Console.WriteLine("Page:" + Convert.ToString(page_counter + "  address:"+ Convert.ToString(data_count-1, 16)));
                                page_data_counter = 0;
                                data_from_board = jtag.ReadByte();
                                if (data_from_board != 0x02)
                                    break;
                                
                            }
                        }
                    }
                    Console.WriteLine("Data count:" + Convert.ToString(data_count-1, 16));
                    //data_from_board = jtag.ReadByte();
                    Console.WriteLine("Rx:" + Convert.ToString(data_from_board, 16));
                }//end if 0x02 received

            }//end using jtaguart
            sr.Close();

            Console.WriteLine("Upload completed. Press a key to exit.");
            Console.ReadKey();

        }

    }
}
